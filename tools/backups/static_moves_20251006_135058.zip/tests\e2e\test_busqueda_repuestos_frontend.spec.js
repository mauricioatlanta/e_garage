// ✅ Prueba end-to-end para búsqueda de repuestos
//
// Valida la funcionalidad de búsqueda de repuestos por código
// y autocompletado de información del repuesto

import { test, expect } from '@playwright/test';

test('búsqueda de repuestos por código y autocompletado', async ({ page }) => {
  // Abre el formulario de documentos
  await page.goto('http://127.0.0.1:8000/us/documentos/form/');

  // Click en "+ Add Part"
  await page.click('#add-repuesto');

  // Espera que aparezca el campo de código para repuesto
  const codeInput = page.locator('.rep-codigo').first();
  await expect(codeInput).toBeVisible();

  // Escribe un código de repuesto conocido
  await codeInput.fill('bra');
  
  // Espera un momento para que se ejecute la búsqueda
  await page.waitForTimeout(1000);

  // Verifica que el campo de nombre se haya autocompletado
  const nameInput = page.locator('.rep-nombre').first();
  const nameValue = await nameInput.inputValue();
  expect(nameValue).not.toBe('');

  // Verifica que el precio de compra se haya autocompletado
  const costPriceInput = page.locator('.rep-precio-compra').first();
  const costPriceValue = await costPriceInput.inputValue();
  expect(costPriceValue).not.toBe('');

  // Verifica que el precio de venta se haya autocompletado
  const salePriceInput = page.locator('.rep-precio-venta').first();
  const salePriceValue = await salePriceInput.inputValue();
  expect(salePriceValue).not.toBe('');

  // Cambia la cantidad a 2
  const quantityInput = page.locator('.rep-cantidad').first();
  await quantityInput.fill('2');

  // Verifica que el subtotal se calcule correctamente
  const subtotalText = await page.locator('.rep-subtotal-view').first().textContent();
  expect(subtotalText).toContain('$');

  // Verifica que el total global se actualizó
  const total = await page.locator('#t_total').textContent();
  expect(total).toContain('$');
});
