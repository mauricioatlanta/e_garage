// ✅ Prueba end-to-end completa del formulario de documentos
//
// Valida el flujo completo: cliente, vehículo, repuestos, servicios y totales

import { test, expect } from '@playwright/test';

test('flujo completo del formulario de documentos', async ({ page }) => {
  // Abre el formulario de documentos
  await page.goto('http://127.0.0.1:8000/us/documentos/form/');

  // 1. Seleccionar tipo de documento
  await page.selectOption('#id_tipo', 'OT');
  await page.waitForTimeout(500);

  // 2. Buscar y seleccionar cliente
  const clientSearch = page.locator('#cliente-busqueda');
  await clientSearch.fill('jac');
  await page.waitForTimeout(1000);

  // Seleccionar el primer cliente de los resultados
  const clientResult = page.locator('#cliente-resultados .cliente-item').first();
  await expect(clientResult).toBeVisible();
  await clientResult.click();

  // 3. Seleccionar vehículo
  const vehicleSelect = page.locator('#id_vehiculo');
  await expect(vehicleSelect).toBeVisible();
  await page.waitForTimeout(500);
  await vehicleSelect.selectOption({ index: 1 }); // Selecciona el primer vehículo disponible

  // 4. Agregar un repuesto
  await page.click('#add-repuesto');
  const repCodeInput = page.locator('.rep-codigo').first();
  await repCodeInput.fill('bra');
  await page.waitForTimeout(1000);

  // Verificar que se autocompletó la información del repuesto
  const repName = await page.locator('.rep-nombre').first().inputValue();
  expect(repName).not.toBe('');

  // 5. Agregar un servicio
  await page.click('#add-servicio');
  const serviceInput = page.locator('.srv-input').first();
  await serviceInput.fill('oil');
  await page.waitForTimeout(1000);

  // Seleccionar el primer servicio
  const serviceDropdown = page.locator('.srv-dropdown');
  await expect(serviceDropdown).toBeVisible();
  const firstService = serviceDropdown.locator('.srv-item').first();
  await firstService.click();

  // 6. Verificar que los totales se calculan correctamente
  const partsSubtotal = await page.locator('#t_repuestos').textContent();
  const servicesSubtotal = await page.locator('#t_servicios').textContent();
  const total = await page.locator('#t_total').textContent();

  expect(partsSubtotal).toContain('$');
  expect(servicesSubtotal).toContain('$');
  expect(total).toContain('$');

  // 7. Verificar que el formulario está listo para enviar
  const submitButton = page.locator('button[type="submit"]');
  await expect(submitButton).toBeVisible();
  await expect(submitButton).toBeEnabled();

  // 8. Verificar que el número de documento se generó automáticamente
  const docNumber = await page.locator('#id_numero').inputValue();
  expect(docNumber).not.toBe('');
  expect(docNumber).toMatch(/^OT-\d+$/); // Formato: OT-XXXX
});
