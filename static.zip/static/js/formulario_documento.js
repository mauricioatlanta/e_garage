// --- FORMATO CHILENO DE MONEDA ---
function formatoSCL(valor) {
    if (isNaN(valor)) return '$0';
    return '$' + valor.toLocaleString('es-CL', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
}

// --- FUNCIÓN PRINCIPAL DE ACTUALIZACIÓN DE TOTALES ---
function actualizarTotalesDocumento() {
    console.log('[DEBUG] actualizarTotalesDocumento() llamada');
    // Sumar totales de repuestos y servicios
    let totalRepuestos = 0;
    let totalServicios = 0;
    
    // Calcular total repuestos
    document.querySelectorAll('#tabla-repuestos tbody tr').forEach((row) => {
        const cantidad = parseInt(row.querySelector('.cantidad-input')?.value || '1');
        const precio = parseInt(row.querySelector('.precio-input')?.value || '0');
        totalRepuestos += cantidad * precio;
    });
    
    // Calcular total servicios
    document.querySelectorAll('#tabla-servicios tbody tr').forEach((row) => {
        const precio = parseInt(row.querySelector('.precio-servicio-input')?.value || '0');
        totalServicios += precio;
    });
    
    const subtotal = totalRepuestos + totalServicios;
    const iva = Math.round(subtotal * 0.19);
    const granTotal = subtotal + iva;
    
    console.log(`[DEBUG] Totales calculados - Repuestos: ${totalRepuestos}, Servicios: ${totalServicios}, Total: ${granTotal}`);
    
    // Actualizar elementos del DOM si existen
    const elementos = {
        'subtotal-doc': subtotal,
        'iva-doc': iva,
        'gran-total-doc': granTotal,
        'total-repuestos': totalRepuestos,
        'total-servicios': totalServicios,
        'display-total-repuestos': totalRepuestos,
        'display-total-servicios': totalServicios,
        'display-subtotal': subtotal,
        'display-iva': iva,
        'display-total': granTotal
    };
    
    Object.entries(elementos).forEach(([id, valor]) => {
        const elemento = document.getElementById(id);
        if (elemento) {
            elemento.textContent = formatoSCL(valor);
            console.log(`[DEBUG] Actualizado ${id}: ${formatoSCL(valor)}`);
        }
    });
}

// Hacer disponible globalmente
window.actualizarTotalesDocumento = actualizarTotalesDocumento;

// --- AUTOCOMPLETADO INTELIGENTE DE REPUESTOS Y SERVICIOS ---
function activarAutocompleteRepuesto(tr) {
    const partInput = tr.querySelector('.partnumber-input');
    const nombreInput = tr.querySelector('.nombre-input');
    const precioInput = tr.querySelector('.precio-input');
    if (!partInput) return;
    
    // Mostrar mensaje si el partnumber no existe y autocompletar si existe
    partInput.addEventListener('blur', function() {
        const valor = partInput.value.trim();
        if (!valor) return;
        $.getJSON('/documentos/autocomplete_repuesto/', {q: valor}, function(data) {
            const match = data.results.find(r => r.partnumber === valor);
            if (!match) {
                partInput.classList.add('border-red-500');
                if (!tr.querySelector('.msg-noexiste')) {
                    const msg = document.createElement('div');
                    msg.textContent = '⚠️ Repuesto no existe';
                    msg.className = 'msg-noexiste text-red-600 text-xs mt-1';
                    partInput.parentNode.appendChild(msg);
                }
            } else {
                partInput.classList.remove('border-red-500');
                const msg = tr.querySelector('.msg-noexiste');
                if (msg) msg.remove();
                if (nombreInput) nombreInput.value = match.nombre;
                if (precioInput) precioInput.value = match.precio;
                setTimeout(() => actualizarTotalRepuestos(), 100);
            }
        });
    });
    
    $(partInput).autocomplete({
        source: function(request, response) {
            $.getJSON('/documentos/autocomplete_repuesto/', {q: request.term}, function(data) {
                response(data.results.map(r => ({
                    label: r.partnumber + ' - ' + r.nombre + ' ($' + r.precio + ')',
                    value: r.partnumber,
                    nombre: r.nombre,
                    precio: r.precio
                })));
            });
        },
        minLength: 2,
        select: function(event, ui) {
            if (nombreInput) nombreInput.value = ui.item.nombre;
            if (precioInput) precioInput.value = ui.item.precio;
            setTimeout(() => actualizarTotalRepuestos(), 100);
        }
    });
}

function activarAutocompleteServicio(tr) {
    const nombreInput = tr.querySelector('.nombre-servicio-input');
    const precioInput = tr.querySelector('.precio-servicio-input');
    if (!nombreInput) return;
    
    // Autocompletar precio si el servicio existe
    nombreInput.addEventListener('blur', function() {
        const valor = nombreInput.value.trim();
        if (!valor) return;
        $.getJSON('/documentos/autocomplete_servicio_nombre/', {q: valor}, function(data) {
            const match = data.results.find(s => s.nombre.toLowerCase() === valor.toLowerCase());
            if (match && precioInput) {
                precioInput.value = match.precio || 0;
                setTimeout(() => actualizarTotalServicios(), 100);
            }
        });
    });
    
    $(nombreInput).autocomplete({
        source: function(request, response) {
            $.getJSON('/documentos/autocomplete_servicio_nombre/', {q: request.term}, function(data) {
                response(data.results.map(s => ({
                    label: s.nombre + (s.precio ? ' ($' + s.precio + ')' : ''),
                    value: s.nombre,
                    precio: s.precio
                })));
            });
        },
        minLength: 2,
        select: function(event, ui) {
            if (precioInput && ui.item.precio) {
                precioInput.value = ui.item.precio;
                setTimeout(() => actualizarTotalServicios(), 100);
            }
        }
    });
}

// --- FUNCIONES PARA AGREGAR REPUESTOS Y SERVICIOS ---
function agregarRepuesto() {
    console.log('[DEBUG] agregarRepuesto() llamada');
    const tbody = document.querySelector('#tabla-repuestos tbody');
    if (!tbody) {
        console.error('[ERROR] No se encontró #tabla-repuestos tbody');
        return;
    }
    
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" class="partnumber-input futurista-input border p-1 rounded w-full" placeholder="Partnumber"></td>
        <td><input type="text" class="nombre-input futurista-input border p-1 rounded w-full" placeholder="Nombre"></td>
        <td><input type="number" class="cantidad-input futurista-input border p-1 rounded w-20" value="1" min="1"></td>
        <td><input type="number" class="precio-input futurista-input border p-1 rounded w-24" value="0" min="0"></td>
        <td class="subtotal-repuesto font-semibold">$0</td>
        <td><button type="button" class="text-red-600 font-bold" onclick="this.closest('tr').remove(); actualizarTotalRepuestos();">✖</button></td>
    `;
    tbody.appendChild(tr);
    console.log('[DEBUG] Fila de repuesto agregada');
    
    activarAutocompleteRepuesto(tr);
    
    // Conectar eventos de cálculo a ambos inputs
    const cantidadInput = tr.querySelector('.cantidad-input');
    const precioInput = tr.querySelector('.precio-input');
    if (cantidadInput) cantidadInput.addEventListener('input', actualizarTotalRepuestos);
    if (precioInput) precioInput.addEventListener('input', actualizarTotalRepuestos);
    
    // Calcular total al crear la fila
    actualizarTotalRepuestos();
    
    // Poner foco en el primer input
    const primerInput = tr.querySelector('.partnumber-input');
    if (primerInput) primerInput.focus();
}

function agregarServicio() {
    console.log('[DEBUG] agregarServicio() llamada');
    const tbody = document.querySelector('#tabla-servicios tbody');
    if (!tbody) {
        console.error('[ERROR] No se encontró #tabla-servicios tbody');
        return;
    }
    
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" class="nombre-servicio-input futurista-input border p-1 rounded w-full" placeholder="Nombre del servicio"></td>
        <td><input type="number" class="precio-servicio-input futurista-input border p-1 rounded w-24" value="0" min="0"></td>
        <td><button type="button" class="text-red-600 font-bold" onclick="this.closest('tr').remove(); actualizarTotalServicios();">✖</button></td>
    `;
    tbody.appendChild(tr);
    console.log('[DEBUG] Fila de servicio agregada');
    
    activarAutocompleteServicio(tr);
    
    // Conectar evento de cálculo al input de precio
    const precioInput = tr.querySelector('.precio-servicio-input');
    if (precioInput) precioInput.addEventListener('input', actualizarTotalServicios);
    
    // Calcular total al crear la fila
    actualizarTotalServicios();
    
    // Poner el foco en el campo de nombre de servicio
    const inputNombre = tr.querySelector('.nombre-servicio-input');
    if (inputNombre) {
        inputNombre.focus();
    }
}

// Hacer las funciones disponibles globalmente INMEDIATAMENTE
window.agregarRepuesto = agregarRepuesto;
window.agregarServicio = agregarServicio;

// --- FUNCIONES DE EJEMPLO PARA AYUDAR A LOS USUARIOS ---
function agregarRepuestoEjemplo() {
    console.log('[DEBUG] agregarRepuestoEjemplo() llamada');
    agregarRepuesto();
    
    // Llenar con datos de ejemplo
    const lastRow = document.querySelector('#tabla-repuestos tbody tr:last-child');
    if (lastRow) {
        const partnumberInput = lastRow.querySelector('.partnumber-input');
        const nombreInput = lastRow.querySelector('.nombre-input');
        const cantidadInput = lastRow.querySelector('.cantidad-input');
        const precioInput = lastRow.querySelector('.precio-input');
        
        if (partnumberInput) partnumberInput.value = 'FLT-001';
        if (nombreInput) nombreInput.value = 'Filtro de aceite';
        if (cantidadInput) cantidadInput.value = '1';
        if (precioInput) precioInput.value = '15000';
        
        actualizarTotalRepuestos();
        console.log('[DEBUG] Repuesto de ejemplo agregado');
    }
}

function agregarServicioEjemplo() {
    console.log('[DEBUG] agregarServicioEjemplo() llamada');
    agregarServicio();
    
    // Llenar con datos de ejemplo
    const lastRow = document.querySelector('#tabla-servicios tbody tr:last-child');
    if (lastRow) {
        const nombreInput = lastRow.querySelector('.nombre-servicio-input');
        const precioInput = lastRow.querySelector('.precio-servicio-input');
        
        if (nombreInput) nombreInput.value = 'Cambio de aceite';
        if (precioInput) precioInput.value = '25000';
        
        actualizarTotalServicios();
        console.log('[DEBUG] Servicio de ejemplo agregado');
    }
}

window.agregarRepuestoEjemplo = agregarRepuestoEjemplo;
window.agregarServicioEjemplo = agregarServicioEjemplo;

function actualizarTotalRepuestos() {
    console.log('[DEBUG] actualizarTotalRepuestos() llamada');
    let total = 0;
    const rows = document.querySelectorAll('#tabla-repuestos tbody tr');
    console.log(`[DEBUG] Encontradas ${rows.length} filas de repuestos`);
    
    rows.forEach((row, index) => {
        let cantidad = row.querySelector('.cantidad-input')?.value || '1';
        let precio = row.querySelector('.precio-input')?.value || '0';
        // Eliminar separadores, símbolos y convertir a entero
        cantidad = parseInt(cantidad.toString().replace(/[^\d]/g, '')) || 1;
        precio = parseInt(precio.toString().replace(/[^\d]/g, '')) || 0;
        const subtotal = cantidad * precio;
        console.log(`[DEBUG] Repuesto ${index}: cantidad=${cantidad}, precio=${precio}, subtotal=${subtotal}`);
        
        const subtotalElement = row.querySelector('.subtotal-repuesto');
        if (subtotalElement) {
            subtotalElement.textContent = formatoSCL(subtotal);
        }
        total += subtotal;
    });
    
    console.log(`[DEBUG] Total repuestos: ${total}`);
    
    // Si hay al menos un repuesto con subtotal > 0, mostrar el total
    const totalElement = document.getElementById('total-repuestos');
    if (totalElement) {
        totalElement.textContent = formatoSCL(total > 0 ? total : 0);
    }
    
    // Llamar a la función principal de totales
    if (typeof actualizarTotalesDocumento === 'function') {
        actualizarTotalesDocumento();
    }
}

function actualizarTotalServicios() {
    console.log('[DEBUG] actualizarTotalServicios() llamada');
    let total = 0;
    const rows = document.querySelectorAll('#tabla-servicios tbody tr');
    console.log(`[DEBUG] Encontradas ${rows.length} filas de servicios`);
    
    rows.forEach((row, index) => {
        const precio = parseInt(row.querySelector('.precio-servicio-input')?.value || '0');
        console.log(`[DEBUG] Servicio ${index}: precio=${precio}`);
        total += precio;
    });
    
    console.log(`[DEBUG] Total servicios: ${total}`);
    
    const totalElement = document.getElementById('total-servicios');
    if (totalElement) {
        totalElement.textContent = formatoSCL(total);
    }
    
    // Llamar a la función principal de totales
    if (typeof actualizarTotalesDocumento === 'function') {
        actualizarTotalesDocumento();
    }
}

console.log('[DEBUG] formulario_documento.js cargado');

document.addEventListener('DOMContentLoaded', function () {
    // --- Activar autocompletado y eventos en filas precargadas (edición) ---
    document.querySelectorAll('#tabla-repuestos tbody tr').forEach((tr) => {
        activarAutocompleteRepuesto(tr);
        const cantidadInput = tr.querySelector('.cantidad-input');
        const precioInput = tr.querySelector('.precio-input');
        if (cantidadInput) cantidadInput.addEventListener('input', actualizarTotalRepuestos);
        if (precioInput) precioInput.addEventListener('input', actualizarTotalRepuestos);
    });
    
    document.querySelectorAll('#tabla-servicios tbody tr').forEach((tr) => {
        activarAutocompleteServicio(tr);
        const precioInput = tr.querySelector('.precio-servicio-input');
        if (precioInput) precioInput.addEventListener('input', actualizarTotalServicios);
    });
    
    // Calcular totales iniciales
    setTimeout(() => {
        actualizarTotalRepuestos();
        actualizarTotalServicios();
    }, 100);
    
    // Asegurar el evento para el checkbox de IVA
    const checkboxIva = document.getElementById('lleva_iva');
    if (checkboxIva) {
        checkboxIva.addEventListener('change', actualizarTotalesDocumento);
    }
    
    // --- CONFIGURACIÓN DE TIPO DE DOCUMENTO ---
    const tipoDocSelect = document.getElementById('id_tipo_documento');
    const numeroInput = document.getElementById('id_numero_documento');
    const formContainer = document.getElementById('form-doc-container');

    const configPorTipo = {
        'Factura': { style: 'background:rgba(255,255,0,0.12);border:2px solid #ffe066;', prefijo: 'F-' },
        'Orden de trabajo': { style: 'background:rgba(0,180,255,0.12);border:2px solid #4fc3f7;', prefijo: 'OT-' },
        'Presupuesto': { style: 'background:rgba(128,0,255,0.12);border:2px solid #b39ddb;', prefijo: 'P-' },
    };

    const generarNumero = (tipo) => {
        const conf = configPorTipo[tipo] || { prefijo: 'X-' };
        const rnd = Math.floor(Math.random() * 999) + 1;
        const num = rnd.toString().padStart(3, '0');
        return conf.prefijo + num;
    };

    function actualizarColor(tipo) {
        if (formContainer) {
            formContainer.removeAttribute('style');
            const estilo = configPorTipo[tipo]?.style || '';
            if (estilo) {
                formContainer.setAttribute('style', estilo);
            }
        }
    }

    if (tipoDocSelect && numeroInput) {
        tipoDocSelect.addEventListener('change', function () {
            const tipo = tipoDocSelect.value;
            if (tipo) {
                numeroInput.value = generarNumero(tipo);
                actualizarColor(tipo);
            }
        });

        // Configuración inicial
        const tipoInicial = tipoDocSelect.value;
        if (tipoInicial) {
            actualizarColor(tipoInicial);
            if (!numeroInput.value) {
                numeroInput.value = generarNumero(tipoInicial);
            }
        }
    }

    // Fallback por si no engancha el onclick
    const btnRepuesto = document.querySelector('button[onclick="agregarRepuesto()"]');
    if (btnRepuesto) {
        btnRepuesto.addEventListener('click', function(e) {
            e.preventDefault();
            window.agregarRepuesto();
        });
    }

    const btnServicio = document.getElementById('btn-agregar-servicio');
    if (btnServicio) {
        btnServicio.addEventListener('click', function(e) {
            e.preventDefault();
            window.agregarServicio();
        });
    }

    // Evento de envío del formulario
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function (e) {
            console.log('[SUBMIT] Iniciando envío del formulario...');
            
            // --- PARCHE SELECT2 AJAX: asegurar que el valor seleccionado esté como <option> en el <select> ---
            ['id_cliente', 'id_vehiculo', 'id_mecanico'].forEach(function(id) {
                const select = document.getElementById(id);
                if (select && select.classList.contains('select2-hidden-accessible')) {
                    const value = $(select).val();
                    if (value && !select.querySelector('option[value="' + value + '"]')) {
                        // Obtener el texto visible de select2
                        const text = $(select).select2('data')[0]?.text || '';
                        const option = document.createElement('option');
                        option.value = value;
                        option.text = text;
                        option.selected = true;
                        select.appendChild(option);
                        console.log(`[SUBMIT] Opción agregada para ${id}: ${value} - ${text}`);
                    }
                }
            });

            const items = [];
            let repuestosProcessed = 0;
            let serviciosProcessed = 0;

            // Procesar repuestos
            const repuestoRows = document.querySelectorAll('#tabla-repuestos tbody tr');
            console.log(`[SUBMIT] Encontradas ${repuestoRows.length} filas de repuestos`);
            
            repuestoRows.forEach((row, index) => {
                const partnumber = row.querySelector('.partnumber-input')?.value?.trim() || '';
                const nombre = row.querySelector('.nombre-input')?.value?.trim() || '';
                const cantidadStr = row.querySelector('.cantidad-input')?.value || '1';
                const precioStr = row.querySelector('.precio-input')?.value || '0';
                
                // Limpiar valores numéricos
                const cantidad = parseInt(cantidadStr.replace(/[^\d]/g, '')) || 1;
                const precio = parseInt(precioStr.replace(/[^\d]/g, '')) || 0;

                console.log(`[SUBMIT] Repuesto ${index}: partnumber="${partnumber}", nombre="${nombre}", cantidad=${cantidad}, precio=${precio}`);

                if (nombre.length > 0 && precio > 0) {
                    const item = {
                        tipo: 'repuesto',
                        partnumber: partnumber,
                        nombre: nombre,
                        cantidad: cantidad,
                        precio: precio
                    };
                    items.push(item);
                    repuestosProcessed++;
                    console.log(`[SUBMIT] ✅ Repuesto agregado:`, item);
                } else {
                    console.log(`[SUBMIT] ❌ Repuesto ${index} rechazado - nombre: "${nombre}" (${nombre.length} chars), precio: ${precio}`);
                }
            });

            // Procesar servicios
            const servicioRows = document.querySelectorAll('#tabla-servicios tbody tr');
            console.log(`[SUBMIT] Encontradas ${servicioRows.length} filas de servicios`);
            
            servicioRows.forEach((row, index) => {
                let nombre = '';
                const nombreInput = row.querySelector('.nombre-servicio-input');
                if (nombreInput) {
                    if (nombreInput.tagName === 'SELECT') {
                        nombre = nombreInput.options[nombreInput.selectedIndex]?.text?.trim() || '';
                    } else {
                        nombre = nombreInput.value?.trim() || '';
                    }
                }
                const precioStr = row.querySelector('.precio-servicio-input')?.value || '0';
                const precio = parseInt(precioStr.replace(/[^\d]/g, '')) || 0;
                
                console.log(`[SUBMIT] Servicio ${index}: nombre="${nombre}", precio=${precio}`);
                
                if (nombre.length > 0 && precio > 0) {
                    const item = {
                        tipo: 'servicio',
                        nombre: nombre,
                        precio: precio
                    };
                    items.push(item);
                    serviciosProcessed++;
                    console.log(`[SUBMIT] ✅ Servicio agregado:`, item);
                } else {
                    console.log(`[SUBMIT] ❌ Servicio ${index} rechazado - nombre: "${nombre}" (${nombre.length} chars), precio: ${precio}`);
                }
            });

            console.log(`[SUBMIT] RESUMEN FINAL: ${items.length} items totales (${repuestosProcessed} repuestos, ${serviciosProcessed} servicios)`);

            // VALIDACIÓN IMPORTANTE: Alertar si no hay items
            if (items.length === 0) {
                const confirmar = confirm(
                    '⚠️ DOCUMENTO VACÍO\n\n' +
                    'No hay repuestos ni servicios agregados.\n' +
                    'El documento se creará sin items.\n\n' +
                    '¿Desea continuar?\n\n' +
                    'Presione "Cancelar" para agregar repuestos/servicios primero.'
                );
                
                if (!confirmar) {
                    e.preventDefault();
                    console.log('[SUBMIT] ❌ Envío cancelado por usuario - documento vacío');
                    alert('💡 SUGERENCIA:\n\n1. Use los botones "➕ Agregar repuesto" o "🔧 Agregar Servicio"\n2. O use los botones "📋 Ejemplo" para ver cómo llenar los datos\n3. Luego presione "Guardar Documento"');
                    return false;
                }
            } else {
                console.log(`[SUBMIT] ✅ Documento con ${items.length} items listo para envío`);
            }

            const jsonInput = document.getElementById('json_items');
            if (jsonInput) {
                const jsonData = JSON.stringify(items);
                jsonInput.value = jsonData;
                console.log(`[SUBMIT] json_items configurado (${jsonData.length} chars):`, jsonData);
                
                // Verificar que el campo no esté vacío
                if (items.length === 0) {
                    console.warn('⚠️ [SUBMIT] ADVERTENCIA: No hay items para enviar - documento se creará vacío (confirmado por usuario)');
                }
                if (jsonData === '[]') {
                    console.warn('⚠️ [SUBMIT] ADVERTENCIA: json_items es array vacío (confirmado por usuario)');
                }
            } else {
                console.error('❌ [SUBMIT] ERROR CRÍTICO: No se encontró input#json_items en el formulario');
                // Intentar crear el campo si no existe
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.id = 'json_items';
                hiddenInput.name = 'json_items';
                hiddenInput.value = JSON.stringify(items);
                form.appendChild(hiddenInput);
                console.log('[SUBMIT] Campo json_items creado dinámicamente');
            }
            
            // Validación final antes del envío
            const finalJsonValue = document.getElementById('json_items')?.value;
            console.log(`[SUBMIT] Valor final de json_items antes del envío: "${finalJsonValue}"`);
        });
    } else {
        console.error('❌ No se encontró el formulario para agregar event listener');
    }
});
