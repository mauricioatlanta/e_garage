// ✅ Prueba end-to-end con Playwright (Node.js)
//
// Ejecuta con:
//   npx playwright test tests/e2e/test_busqueda_servicios_frontend.spec.js
//
// Requisitos:
//   - servidor local corriendo (http://127.0.0.1:8000)
//   - usuario autenticado o login automático (puedes mockearlo con sesión de test)

import { test, expect } from '@playwright/test';

test('búsqueda de servicios en tiempo real y autocompletado de precio', async ({ page }) => {
  // Abre el formulario de documentos (ajusta URL a tu entorno)
  await page.goto('http://127.0.0.1:8000/us/documentos/form/');

  // Click en "+ Add Service"
  await page.click('#add-servicio');

  // Espera que aparezca el campo de texto para servicio
  const input = page.locator('.srv-input').first();
  await expect(input).toBeVisible();

  // Escribe parte del nombre de un servicio conocido
  await input.fill('oil');
  // Espera el dropdown con resultados
  const dropdown = page.locator('.srv-dropdown');
  await expect(dropdown).toBeVisible();

  // Selecciona el primer resultado
  const firstResult = dropdown.locator('.srv-item').first();
  await firstResult.click();

  // Verifica que el input tenga el nombre del servicio seleccionado
  const value = await input.inputValue();
  expect(value.toLowerCase()).toContain('oil');

  // Verifica que el precio se haya autocompletado
  const priceInput = page.locator('.serv-precio').first();
  const priceValue = await priceInput.inputValue();
  expect(priceValue).not.toBe('');

  // Verifica que el subtotal muestre el mismo valor formateado
  const subtotalText = await page.locator('.serv-subtotal-view').first().textContent();
  expect(subtotalText).toContain('$');

  // Verifica que el total global se actualizó
  const total = await page.locator('#t_total').textContent();
  expect(total).toContain('$');
});
